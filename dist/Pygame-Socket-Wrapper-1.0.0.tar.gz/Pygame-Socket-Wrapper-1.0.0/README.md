# Pygame-Socket-Wrapper
Socket wrapper for sending and receiving packets

### it adds `SocketWrapper` and `Packet` classes.
`SocketWrapper` is for client/server code, while `Packet` is used to pass data to `SocketWrapper`.

More documentation is in code.